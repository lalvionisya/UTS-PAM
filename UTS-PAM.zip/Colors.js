export default colors = {
    black: '#2D3436',
    blue: '#24A6D9',
    lightblue: '##A7CBD9',
    white: '#FFFFFF',
    gray: '#A4A4A4',
    lightgrey: '#CACACA'
};