export default tempData = [
    {
        name: "Data Mahasiswa",
        color: "#D88559",
        todos: [
            {
                title: "Lidia Alvionisya Alami",
                completed: false
            },
            {
                title: "120140042",
                completed: true
            },
            {
                title: "Pemrograman Aplikasi Mobile RB",
                completed: false
            },
            {
                title: "Teknik Informatika",
                completed: true
            }
        ]
    },
    {
        name: "Bersih-bersih",
        color: "#24A6D9",
        todos: [
            {
                title: "Nyapu",
                completed: false
            },
            {
                title: "Pel",
                completed: true
            },
            {
                title: "Cuci baju",
                completed: false
            },
            {
                title: "Cuci piring",
                completed: true
            }
        ]
    },

    {
        name: "Tugas Kuliah",
        color: "#595BD9",
        todos: [
            {
                title: "Metodologi Penelitian",
                completed: false
            },
            {
                title: "PAM",
                completed: true
            },
            {
                title: "Sistem Tertanam",
                completed: true
            },
        ]
    }
]